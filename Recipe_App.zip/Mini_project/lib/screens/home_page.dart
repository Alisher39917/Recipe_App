import 'package:flutter/material.dart';
import 'recipe_model.dart';
import 'recipe_detail_page.dart';
import 'categories_page.dart';

class HomePage extends StatelessWidget {
  final List<Recipe> recipes = [
    Recipe(
      title: 'Spaghetti Carbonara',
      imagePath: 'Spaghetti.png',  // Correct path for the local image
      ingredients: ['Spaghetti', 'Eggs', 'Pancetta', 'Parmesan', 'Pepper'],
      description: 'A classic Italian pasta dish.',
    ),
    Recipe(
      title: 'Chicken Curry',
      imagePath: 'Chicken.png',  // Correct path for the local image
      ingredients: ['Chicken', 'Curry Powder', 'Coconut Milk', 'Onions'],
      description: 'A spicy and flavorful dish.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Recipe Book')),
      body: SingleChildScrollView(
        child: Column(
          children: recipes.map((recipe) {
            return GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => RecipeDetailPage(recipe: recipe),
                  ),
                );
              },
              child: Card(
                margin: EdgeInsets.all(10),
                elevation: 5,
                child: Column(
                  children: [
                    // Use Image.asset() for loading local images
                    Image.asset('assets/images/${recipe.imagePath}'),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        recipe.title,
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => CategoriesPage()),
          );
        },
        child: Icon(Icons.category),
      ),
    );
  }
}
