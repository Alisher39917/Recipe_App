import 'package:flutter/material.dart';
import 'recipe_model.dart';

class RecipeDetailPage extends StatelessWidget {
  final Recipe recipe;

  RecipeDetailPage({required this.recipe});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(recipe.title)),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Display the local image using Image.asset()
            Image.asset('assets/images/${recipe.imagePath}'),

            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(recipe.description, style: TextStyle(fontSize: 16)),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text('Ingredients:', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ),
            // Display the list of ingredients
            ...recipe.ingredients.map((ingredient) => ListTile(title: Text(ingredient))).toList(),
          ],
        ),
      ),
    );
  }
}
