class Recipe {
  final String title; // Recipe title
  final String imagePath; // Path to the image (local or network)
  final List<String> ingredients; // List of ingredients
  final String description; // Description of the recipe

  // Constructor for initializing the fields
  Recipe({
    required this.title,
    required this.imagePath,
    required this.ingredients,
    required this.description,

  });
}
