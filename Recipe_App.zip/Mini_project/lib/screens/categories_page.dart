// categories_page.dart
import 'package:flutter/material.dart';

class CategoriesPage extends StatelessWidget {
  final List<String> categories = [
    'Italian',
    'Indian',
    'Chinese',
    'Mexican',
    'Desserts',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Categories')),
      body: ListView.builder(
        itemCount: categories.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              title: Text(categories[index], style: TextStyle(fontSize: 18)),
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Selected Category: ${categories[index]}')),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
